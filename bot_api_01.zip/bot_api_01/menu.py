from aiogram import types
from aiogram.dispatcher import FSMContext

from .app import dp, bot
from .keyboards import inline_kb, inline_menu
from .data_fetcher import get_category, get_menu


@dp.message_handler(commands = 'category_menu', state = '*')
async def categories_menu(message: types.Message):
    await message.reply(f'Посмотри на категорий меню:', reply_markup = inline_kb)


@dp.callback_query_handler(lambda cat: cat.data in ['Завтрак', 'Обед', 'Ужин'])
async def button_click_call_back(callback_query: types.CallbackQuery, state: FSMContext):
    await bot.answer_callback_query(callback_query.id)
    category = callback_query.data
    dish = await get_category()
    for index in range(0, len(dish)):
        dish_ind = dish[index]
        if dish_ind['category'] == category:
            await bot.send_message(callback_query.from_user.id,
                                   f" Блюдо: {dish_ind['name']}\nО блюдо: {dish_ind['content']}\nЦена: {dish_ind['price']} рублей\nКатегория блюдо: {dish_ind['category']}\n{dish_ind['photo']}\n")


@dp.message_handler(commands = 'menu', state = '*')
async def menu(message: types.Message):
    await message.reply(f'Посмотреть все меню?', reply_markup = inline_menu)


@dp.callback_query_handler(lambda menu_list: menu_list.data in ['Да', 'Нет'])
async def button_menu(callback_query: types.CallbackQuery, state: FSMContext):
    await bot.answer_callback_query(callback_query.id)
    answer = callback_query.data
    menu = await get_menu()
    if answer == 'Да':
        for menu_list in menu:
                await bot.send_message(callback_query.from_user.id,
                                       f" Блюдо: {menu_list['name']}\nО блюдо: {menu_list['content']}\nЦена: {menu_list['price']} рублей\nКатегория блюдо: {menu_list['category']}\n{menu_list['photo']}\n")
    else:
        await bot.send_message(callback_query.from_user.id, 'Хорошо) Если передумаете, то команда /menu поможет')
