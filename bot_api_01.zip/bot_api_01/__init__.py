import logging
from .app import dp
from . import commands

logging.basicConfig(level = logging.INFO)


