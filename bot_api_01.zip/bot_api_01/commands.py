from aiogram import types

from .app import dp
from .messages import WELCOME_MESSAGE


@dp.message_handler(commands = ['start'])
async def send_welcome(message: types.Message):
    await message.reply(WELCOME_MESSAGE)


@dp.message_handler(commands = ['link_to_site'])
async def send_welcome(message: types.Message):
    await message.reply("Ссылка на сайт: \n http://127.0.0.1:8000/main/")

