API_KEY = ''


CATEGORY_MENU = 'http://127.0.0.1:8000/api/menu_list/'

MENU = 'http://127.0.0.1:8000/api/menu_list/'