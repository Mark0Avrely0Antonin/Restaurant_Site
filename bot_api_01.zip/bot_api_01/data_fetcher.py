import aiohttp

from .local_settings import CATEGORY_MENU, MENU


async def get_category():
    async with aiohttp.ClientSession(trust_env = True) as session:
        async with session.get(CATEGORY_MENU) as categories:
            return await categories.json()


async def get_menu():
    async with aiohttp.ClientSession(trust_env = True) as session_menu:
        async with session_menu.get(MENU) as menu:
            return await menu.json()
