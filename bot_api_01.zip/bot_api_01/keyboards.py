from aiogram.types import KeyboardButton, ReplyKeyboardMarkup, InlineKeyboardButton, InlineKeyboardMarkup

inline_button_breakfast = InlineKeyboardButton('Завтрак', callback_data = 'Завтрак')
inline_button_lunch = InlineKeyboardButton('Обед', callback_data = 'Обед')
inline_button_dinner = InlineKeyboardButton('Ужин', callback_data = 'Ужин')

inline_kb = InlineKeyboardMarkup()

inline_kb.add(inline_button_breakfast)
inline_kb.add(inline_button_lunch)
inline_kb.add(inline_button_dinner)


inline_button_menu_yes = InlineKeyboardButton('Да', callback_data = 'Да')
inline_button_menu_no = InlineKeyboardButton('Нет', callback_data = 'Нет')

inline_menu = InlineKeyboardMarkup()
inline_menu.add(inline_button_menu_yes)
inline_menu.add(inline_button_menu_no)